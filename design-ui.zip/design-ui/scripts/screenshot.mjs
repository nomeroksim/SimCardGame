#!/usr/bin/env node
/**
 * design-ui · screenshot.mjs
 * Снимает скриншоты страниц в нескольких ширинах, чтобы посмотреть на результат глазами.
 *
 * Использование:
 *   node scripts/screenshot.mjs http://localhost:3000 [/shop /servers ...] [опции]
 *
 * Опции:
 *   --widths 360,768,1440   ширины вьюпорта (по умолчанию 360,768,1440)
 *   --out shots             папка для PNG (по умолчанию ./shots)
 *   --full                  полная высота страницы (по умолчанию: да; --no-full — только первый экран)
 *   --theme dark|light      эмуляция prefers-color-scheme (по умолчанию dark)
 *   --reduced-motion        эмуляция prefers-reduced-motion: reduce
 *   --wait 800              пауза после загрузки, мс (анимации, шрифты)
 *   --selector ".hero"      снять только элемент
 *
 * Требует playwright в проекте:  npm i -D playwright && npx playwright install chromium
 * Результат: shots/<path>-<width>.png ; затем открыть PNG инструментом чтения изображений.
 */

import { mkdir } from 'node:fs/promises'
import path from 'node:path'

const args = process.argv.slice(2)
const opts = { widths: [360, 768, 1440], out: 'shots', full: true, theme: 'dark', reducedMotion: false, wait: 800, selector: null }
const targets = []

for (let i = 0; i < args.length; i++) {
  const a = args[i]
  if (a === '--widths') opts.widths = args[++i].split(',').map(Number).filter(Boolean)
  else if (a === '--out') opts.out = args[++i]
  else if (a === '--full') opts.full = true
  else if (a === '--no-full') opts.full = false
  else if (a === '--theme') opts.theme = args[++i]
  else if (a === '--reduced-motion') opts.reducedMotion = true
  else if (a === '--wait') opts.wait = Number(args[++i])
  else if (a === '--selector') opts.selector = args[++i]
  else targets.push(a)
}

if (targets.length === 0) {
  console.error('Укажи базовый URL: node scripts/screenshot.mjs http://localhost:3000 [/shop ...]')
  process.exit(1)
}

let chromium
try {
  ;({ chromium } = await import('playwright'))
} catch {
  try {
    const { createRequire } = await import('node:module')
    const { execSync } = await import('node:child_process')
    const req = createRequire(import.meta.url)
    let mod
    try { mod = req('playwright') } catch {
      const globalRoot = execSync('npm root -g', { encoding: 'utf8' }).trim()
      mod = req(path.join(globalRoot, 'playwright'))
    }
    chromium = mod.chromium
  } catch {
    console.error('Playwright не найден. Установи: npm i -D playwright && npx playwright install chromium')
    process.exit(1)
  }
}

const base = targets[0].startsWith('http') ? targets[0] : `http://${targets[0]}`
const paths = targets.length > 1 ? targets.slice(1) : ['/']
const urls = paths.map((p) => (p.startsWith('http') ? p : new URL(p, base).toString()))

await mkdir(opts.out, { recursive: true })

const browser = await chromium.launch()
const context = await browser.newContext({
  colorScheme: opts.theme === 'light' ? 'light' : 'dark',
  reducedMotion: opts.reducedMotion ? 'reduce' : 'no-preference',
  deviceScaleFactor: 1,
  locale: 'ru-RU',
})

const slug = (u) => {
  const { pathname } = new URL(u)
  return pathname === '/' ? 'home' : pathname.replace(/^\/|\/$/g, '').replace(/[^\w-]+/g, '-')
}

const results = []
for (const url of urls) {
  for (const width of opts.widths) {
    const page = await context.newPage()
    await page.setViewportSize({ width, height: Math.round(width < 768 ? 800 : 900) })
    const errors = []
    page.on('pageerror', (e) => errors.push(e.message))
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()) })
    try {
      await page.goto(url, { waitUntil: 'networkidle', timeout: 45000 })
      await page.evaluate(() => document.fonts?.ready)
      await page.waitForTimeout(opts.wait)
      const file = path.join(opts.out, `${slug(url)}-${width}.png`)
      if (opts.selector) {
        const el = page.locator(opts.selector).first()
        await el.screenshot({ path: file })
      } else {
        await page.screenshot({ path: file, fullPage: opts.full })
      }
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth)
      results.push({ url, width, file, overflow, errors })
      console.log(`✓ ${file}${overflow ? '  ⚠ горизонтальный скролл' : ''}${errors.length ? `  ⚠ ошибок в консоли: ${errors.length}` : ''}`)
    } catch (e) {
      console.log(`✗ ${url} @${width}: ${e.message.split('\n')[0]}`)
    } finally {
      await page.close()
    }
  }
}

await browser.close()

const bad = results.filter((r) => r.overflow || r.errors.length)
if (bad.length) {
  console.log('\nПроблемы:')
  for (const r of bad) {
    if (r.overflow) console.log(`  ${r.url} @${r.width}: горизонтальный скролл`)
    for (const e of r.errors.slice(0, 5)) console.log(`  ${r.url} @${r.width}: ${e}`)
  }
}
console.log(`\nГотово: ${results.length} скриншотов в ${opts.out}/ — открой их инструментом чтения изображений и сверь с чеклистом.`)
