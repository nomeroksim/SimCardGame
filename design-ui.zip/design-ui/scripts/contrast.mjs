#!/usr/bin/env node
/**
 * design-ui · contrast.mjs
 * Проверяет контраст пар токенов из tokens.css по WCAG 2.x (AA: текст 4.5:1, крупный текст и UI 3:1).
 *
 * Использование:
 *   node scripts/contrast.mjs app/tokens.css
 *   node scripts/contrast.mjs app/tokens.css --theme light
 *   node scripts/contrast.mjs app/tokens.css --pairs "text-1:bg,accent-fg:accent,online:surface-1"
 *
 * Понимает #hex (3/4/6/8), rgb()/rgba(), ссылки var(--x). Полупрозрачные цвета
 * накладываются на фон пары (композитинг), поэтому rgba-границы тоже проверяются.
 * Код выхода 1, если хотя бы одна пара не прошла порог.
 */

import { readFile } from 'node:fs/promises'

const args = process.argv.slice(2)
const file = args.find((a) => !a.startsWith('--'))
if (!file) {
  console.error('Укажи путь к tokens.css')
  process.exit(1)
}
const theme = args.includes('--theme') ? args[args.indexOf('--theme') + 1] : 'dark'
const pairsArg = args.includes('--pairs') ? args[args.indexOf('--pairs') + 1] : null

const css = await readFile(file, 'utf8')

function extractBlock(src, selectorRe) {
  const out = {}
  const re = new RegExp(`${selectorRe}\\s*\\{([^}]*)\\}`, 'g')
  let m
  while ((m = re.exec(src))) {
    for (const line of m[1].split(';')) {
      const mm = line.match(/--([\w-]+)\s*:\s*([^;]+)/)
      if (mm) out[mm[1]] = mm[2].trim()
    }
  }
  return out
}

let vars = extractBlock(css, ':root')
if (theme === 'light') vars = { ...vars, ...extractBlock(css, ":root\\[data-theme='light'\\]") }

function resolve(name, depth = 0) {
  const raw = vars[name]
  if (!raw || depth > 10) return null
  const ref = raw.match(/^var\(--([\w-]+)\)$/)
  if (ref) return resolve(ref[1], depth + 1)
  return raw
}

function parseColor(str) {
  if (!str) return null
  str = str.trim()
  let m
  if ((m = str.match(/^#([0-9a-f]{3,8})$/i))) {
    let h = m[1]
    if (h.length === 3 || h.length === 4) h = [...h].map((c) => c + c).join('')
    const n = parseInt(h.slice(0, 6), 16)
    const a = h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255, a }
  }
  if ((m = str.match(/^rgba?\(([^)]+)\)$/i))) {
    const parts = m[1].split(/[\s,\/]+/).filter(Boolean).map(Number)
    return { r: parts[0], g: parts[1], b: parts[2], a: parts[3] ?? 1 }
  }
  return null
}

function composite(fg, bg) {
  if (fg.a >= 1) return fg
  return {
    r: fg.r * fg.a + bg.r * (1 - fg.a),
    g: fg.g * fg.a + bg.g * (1 - fg.a),
    b: fg.b * fg.a + bg.b * (1 - fg.a),
    a: 1,
  }
}

function luminance({ r, g, b }) {
  const f = (c) => {
    c /= 255
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
  }
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
}

function ratio(fg, bg) {
  const l1 = luminance(fg)
  const l2 = luminance(bg)
  const [hi, lo] = l1 > l2 ? [l1, l2] : [l2, l1]
  return (hi + 0.05) / (lo + 0.05)
}

const defaultPairs = [
  ['text-1', 'bg'], ['text-2', 'bg'], ['text-3', 'bg'],
  ['text-1', 'surface-1'], ['text-2', 'surface-1'], ['text-3', 'surface-1'],
  ['text-1', 'surface-2'], ['text-2', 'surface-2'], ['text-3', 'surface-2'],
  ['text-1', 'surface-3'], ['text-2', 'surface-3'],
  ['accent-fg', 'accent'], ['accent-fg', 'accent-strong'],
  ['accent', 'bg'], ['accent', 'surface-1'],
  ['online', 'surface-1'], ['warning', 'surface-1'], ['danger', 'surface-1'],
  ['border-strong', 'surface-1'], ['border-strong', 'bg'],
  ['tier-1', 'surface-1'], ['tier-2', 'surface-1'], ['tier-3', 'surface-1'], ['tier-4', 'surface-1'],
]

const pairs = pairsArg ? pairsArg.split(',').map((p) => p.split(':').map((s) => s.trim())) : defaultPairs
const bgBase = parseColor(resolve('bg')) ?? { r: 0, g: 0, b: 0, a: 1 }

let failed = 0
const rows = []
for (const [fgName, bgName] of pairs) {
  const fgRaw = resolve(fgName)
  const bgRaw = resolve(bgName)
  const fgC = parseColor(fgRaw)
  const bgC0 = parseColor(bgRaw)
  if (!fgC || !bgC0) {
    rows.push([`${fgName} / ${bgName}`, '—', 'нет токена или неразбираемый цвет', 'skip'])
    continue
  }
  const bgC = composite(bgC0, bgBase)
  const fg = composite(fgC, bgC)
  const r = ratio(fg, bgC)
  const isBorder = fgName.startsWith('border-')
  const isText = fgName.startsWith('text-') || fgName.endsWith('-fg')
  const threshold = isText ? 4.5 : 3
  if (isBorder) {
    rows.push([`${fgName} / ${bgName}`, r.toFixed(2), 'справочно: граница; 3:1 нужно, только если она единственный признак контрола', r >= 3 ? 'OK' : 'info'])
    continue
  }
  const ok = r >= threshold
  if (!ok) failed++
  rows.push([`${fgName} / ${bgName}`, r.toFixed(2), `порог ${threshold}`, ok ? 'OK' : 'FAIL'])
}

const w = Math.max(...rows.map((r) => r[0].length))
console.log(`Контраст (${theme}) · ${file}\n`)
for (const [pair, val, note, status] of rows) {
  const mark = status === 'OK' ? '✓' : status === 'FAIL' ? '✗' : '·'
  console.log(`${mark} ${pair.padEnd(w)}  ${String(val).padStart(6)}  ${note}`)
}
console.log(`\n${failed === 0 ? 'Все пары проходят AA.' : `Не прошли: ${failed}. Поправь значения токенов или не используй эти пары.`}`)
process.exit(failed ? 1 : 0)
