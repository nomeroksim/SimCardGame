# Типографика

Содержание: 1. Шрифты с кириллицей · 2. Пары по направлениям · 3. Подключение в Next.js · 4. Шкала · 5. Цифры и данные · 6. Правила русской типографики · 7. Антипаттерны

---

## 1. Шрифты с кириллицей (Google Fonts, проверено)

Самая частая поломка игровых сайтов — display-шрифт без кириллицы: латиница в фирменном шрифте, русские заголовки — в системном fallback. Выбирать только из списков ниже или из коммерческих шрифтов с кириллицей через `next/font/local`.

**Display / заголовки**

| Шрифт | Характер | Где уместен |
|---|---|---|
| Unbounded | широкий геометрический гротеск, веса 200–900 | Frost, Synthwave, современные игровые бренды |
| Tektur | угловатый техно, 400–900 | Tactical, Toxic, статистика |
| Oswald | узкий плакатный, 200–700 | Ember, цены и заголовки секций, uppercase |
| Alumni Sans | очень узкий, спортивный, 100–900 | Ember, крупные цифры онлайна |
| Montserrat / Montserrat Alternates | геометрический, 100–900 | Synthwave, молодёжные проекты |
| Exo 2 | техно-гротеск, 100–900 | лаунчеры, HUD |
| Play | квадратный техно, 400/700 | статистика, таблицы серверов |
| Russo One | тяжёлый, «классика СНГ-серверов» | Toxic; только осознанно, иронично |
| Rubik Mono One | моноширинный тяжёлый display | счётчики, бейджи |
| Press Start 2P | пиксельный | ретро-ивенты, 1 заголовок на страницу |
| Playfair Display, Cormorant / Cormorant Garamond, Lora, Literata, Spectral | серифы | Fantasy, Showroom, Luxury |
| Yanone Kaffeesatz, Advent Pro | узкие, лёгкие | подписи, второстепенные заголовки |

**Text / основной**

Inter · Manrope · Onest · Golos Text · Geologica · Rubik · Jost · Roboto / Roboto Flex / Roboto Condensed · IBM Plex Sans · Source Sans 3 · Nunito / Nunito Sans · Mulish · Commissioner · Open Sans · Fira Sans · Ubuntu · PT Sans · Wix Madefor Display / Text · Raleway · Noto Sans.

**Mono (IP, таймеры, SteamID, команды)**

JetBrains Mono · IBM Plex Mono · Fira Code · Roboto Mono · Source Code Pro · PT Mono · Ubuntu Mono.

**Кириллицы НЕТ — не использовать для русского текста:** Bebas Neue, Anton, Teko, Orbitron, Audiowide, Rajdhani, Chakra Petch, Black Ops One, Space Grotesk, Space Mono, Geist / Geist Mono, Sora, Syne, Fraunces, DM Sans, DM Serif, Poppins, Outfit, Urbanist, Lexend, Work Sans, Barlow, Archivo, Plus Jakarta Sans, Figtree, Clash Display, Cabinet Grotesk, Satoshi, General Sans, Bricolage Grotesque, Instrument Sans, Red Hat Display, Inconsolata. Замены: Bebas Neue → Oswald или Alumni Sans; Orbitron / Chakra Petch → Tektur или Exo 2; Space Grotesk → Manrope или Onest; Geist Mono / Space Mono → JetBrains Mono; Clash / Cabinet → Unbounded.

Если бриф настаивает на латинском шрифте без кириллицы — ищи его кириллическую версию у автора (платно) либо подбирай визуально близкую пару и фиксируй это в дизайн-плане.

## 2. Пары по направлениям

| Направление | Display | Text | Mono |
|---|---|---|---|
| Frost | Unbounded 600–800 | Onest | JetBrains Mono |
| Ember / Scrap | Oswald 600–700 или Alumni Sans 700 | Golos Text | IBM Plex Mono |
| Tactical | Tektur 600–700 | Geologica / IBM Plex Sans | JetBrains Mono |
| Synthwave | Montserrat Alternates 800 / Unbounded 700 | Manrope | JetBrains Mono |
| Clean Pro | Inter 600 (−0.02em) / Manrope 700 | тот же | JetBrains Mono |
| Toxic | Russo One / Tektur | Rubik | JetBrains Mono |
| Fantasy | Cormorant 600–700 / Playfair Display 700 | Literata / PT Sans | — |
| Showroom | Playfair Display 500 / Lora 600 | Manrope / Golos Text | — |
| Luxury | Cormorant Garamond 500 | Inter 400 | — |

Одно семейство на всё (Inter, Manrope, Golos Text) — тоже валидный выбор, если характер несёт не шрифт, а арт или цвет. Два семейства должны явно различаться (гротеск + сериф, широкий + узкий), иначе выглядят как ошибка.

## 3. Подключение в Next.js

```ts
// app/fonts.ts
import { Unbounded, Onest, JetBrains_Mono } from 'next/font/google'

export const display = Unbounded({
  subsets: ['cyrillic', 'latin'],
  weight: ['600', '700', '800'],
  variable: '--font-display',
  display: 'swap',
})
export const sans = Onest({
  subsets: ['cyrillic', 'latin'],
  weight: ['400', '500', '600'],
  variable: '--font-sans',
  display: 'swap',
})
export const mono = JetBrains_Mono({
  subsets: ['cyrillic', 'latin'],
  weight: ['400', '600'],
  variable: '--font-mono',
  display: 'swap',
})
```

```tsx
// app/layout.tsx
<html lang="ru" className={cn(display.variable, sans.variable, mono.variable)}>
```

Правила: `subsets` всегда с `'cyrillic'`; только нужные веса (каждый — отдельный файл); `display: 'swap'`; переменные шрифтов попадают в токены (`--font-display` и т. д.), Tailwind берёт их через `@theme`. Коммерческие шрифты — `next/font/local` с woff2 и `cyrillic` в файле.

## 4. Шкала

Плавная шкала через `clamp()`; базовый размер 16 px; межстрочный интервал уменьшается с ростом кегля.

| Токен | Размер | line-height | letter-spacing | Применение |
|---|---|---|---|---|
| `--text-display-xl` | `clamp(2.75rem, 1.5rem + 4.5vw, 5.5rem)` | 1.0 | −0.02em | H1 hero (1 на страницу) |
| `--text-display` | `clamp(2rem, 1.25rem + 2.5vw, 3.5rem)` | 1.05 | −0.015em | H1 внутренних страниц |
| `--text-h2` | `clamp(1.5rem, 1.2rem + 1vw, 2.25rem)` | 1.15 | −0.01em | заголовки секций |
| `--text-h3` | `1.25rem` | 1.3 | 0 | карточки, подзаголовки |
| `--text-lg` | `1.125rem` | 1.55 | 0 | лид-абзац |
| `--text-base` | `1rem` | 1.6 | 0 | текст |
| `--text-sm` | `0.875rem` | 1.5 | 0 | второстепенный текст, таблицы |
| `--text-xs` | `0.75rem` | 1.4 | +0.01em | подписи; меньше 12 px не опускаться |
| `--text-price` | `clamp(1.5rem, 1.25rem + 1vw, 2rem)` | 1 | −0.01em | цена на карточке |

Длина строки 55–75 знаков (`max-w-[65ch]`) для абзацев; серифы — чуть длиннее и с line-height 1.65–1.7.
Веса: display 600–800; заголовки 600; текст 400; выделение в тексте 500–600, не 700. Один-два веса на семейство, не четыре.
Uppercase — только для коротких меток ≤ 2 слов (статус, название тира) с трекингом +0.04–0.08em; не для заголовков секций и не как «eyebrow» над каждым заголовком.

## 5. Цифры и данные

- Всё, что меняется или сравнивается (цены, онлайн, таймер, K/D, таблицы) — `font-variant-numeric: tabular-nums` (`tabular-nums` в Tailwind), чтобы цифры не «прыгали».
- Форматирование — `Intl.NumberFormat('ru-RU')`: `2 081`, `1 156` (неразрывный пробел между разрядами ставит сам форматтер); деньги — `new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB', maximumFractionDigits: 0 }).format(200)` → `200 ₽`.
- Цена крупнее названия товара; старая цена — `line-through text-3` рядом, меньше.
- Таймер: `дд : чч : мм : сс` или `2 д 14 ч 03 мин`, mono или tabular, ведущие нули у минут и секунд.
- Выравнивание чисел в таблицах — по правому краю; текст — по левому.
- K/D с двумя знаками (`9.55`), проценты без дробной части, если точность не нужна.

## 6. Правила русской типографики

- Кавычки «ёлочки» (внутри — „лапки“). Тире — «—» (U+2014) с пробелами; диапазоны и минус — «–» / «−»: `7–30 дней`, `−20%`.
- Неразрывный пробел (`&nbsp;` / U+00A0): перед ₽ и единицами (`200 ₽`, `110 HP`, `40 шт.`), после коротких предлогов и союзов («в субботу», «и вайп»), между инициалами, внутри «12:00 МСК».
- Разряды — узкий неразрывный пробел (U+202F) или обычный nbsp через `Intl`; не точки и не запятые.
- Проценты: в бейджах компактно `−20%`, в тексте по норме `20 %`; главное — единообразно по сайту.
- Даты: «сб, 31 октября, 12:00 МСК»; «До вайпа 2 д 14 ч». Месяцы строчными, в родительном падеже.
- Буква «ё» — по правилам бренда, но единообразно.
- Висячие предлоги в заголовках убирать (`text-wrap: balance` на заголовках, `text-wrap: pretty` на абзацах; nbsp после предлогов в ручных текстах).
- Переносы: `hyphens: auto` с `lang="ru"` допустимы в абзацах, не в заголовках и кнопках.
- Кнопки и подписи — с заглавной первой буквы, остальное строчное («Войти через Steam», не «Войти Через Steam»).

## 7. Антипаттерны

- Display-шрифт без кириллицы (fallback в заголовках).
- Четыре веса одного шрифта на экране; жирный 700 в абзацах.
- ALL-CAPS eyebrow над каждым заголовком; трекинг на строчных.
- Текст 11 px; серый `text-3` на арте без подложки.
- Прыгающие цифры в таймере без `tabular-nums`.
- Дефис вместо тире; "программистские" кавычки; `200₽` без пробела; `200 руб.` вместо знака.
- Центрирование длинных абзацев; строка длиннее 90 знаков.
- Один выделенный цветом «эффектный» глагол в заголовке как единственный типографический приём.
